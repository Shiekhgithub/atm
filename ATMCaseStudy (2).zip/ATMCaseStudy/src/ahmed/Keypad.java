/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ahmed;

import java.util.Scanner; // program uses Scanner to obtain user input

public class Keypad {
    private Scanner input; // reads data from the command line
    
    // no-argument constructor initializes the Scanner
    public Keypad() {
        input = new Scanner(System.in); 
    } 

    // return an integer value entered by user
    public int getInput() {
        return input.nextInt(); // we assume that user enters an integer
    } 
} 

